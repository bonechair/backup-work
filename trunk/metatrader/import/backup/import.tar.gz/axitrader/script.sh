#!/bin/bash

echo "Running Import";
cd /var/www/import/axitrader
wget http://www.myfxbook.com/statements/743390/statement.csv
mv statement.csv axitrader.csv
chmod 777 axitrader.csv
php -f axitraderimport.php 