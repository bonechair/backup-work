#!/bin/bash

echo "Running Import";
cd /var/www/import/johnpaul
wget http://www.myfxbook.com/statements/786533/statement.csv
mv statement.csv johnpaul77.csv
chmod 777 johnpaul77.csv
php -f johnpaulimport.php 