<?php


$objects = json_decode($json);
    
    
function get_numerics ($str) {
        preg_match_all('/\d+/', $str, $matches);
        return $matches[0];
    }
foreach($objects->Positions as $object) {

	foreach($object as $obj) {

	     $op = $obj->OpenRate;
	     if(empty($op))continue; 
    
	    $opentime=preg_replace("/[^0-9]/", '', $obj->OriginalOpenDate);
	   preg_match('/[0-9]+/', $opentime, $matches);
	    
	    if($obj->IsBuy == 1)$trade="Buy";  else $trade = 'Sell';  
	    $symbol=str_replace("-", "", $obj->Market->Symbol->Name);
	    $symbol=strtoupper($symbol);	    
	    $sl =$obj->StopLoss;
	    $tp =$obj->TakeProfit;
	    $closetime=$obj->CloseDate;   
	    $cp=$obj->CloseRate;	        
 
	        $date1 = date('Y-m-d H:i:s', $matches[0]/1000);

		$sql = sprintf( "SELECT symbol FROM signals WHERE opendate= '%s' AND author = '%s' AND op = '%s' ", $date1,  $traderfile, $op);
		$result = mysql_query( $sql ) or die( mysql_error() );
		$row = mysql_fetch_array($result);
		$symbol1= $row['symbol'];
		
		if($symbol1)
		{
		
		   $data = "UPDATE signals SET tp='" . $tp . "' , st='" . $sl . "'   WHERE op='" . $op . "' AND opendate='".$date1."' AND symbol='".$symbol1."' and author = '" . $traderfile  ."')"; 
		
		}
		else {
		  
		  $data = "INSERT INTO signals (opendate, op, tp, st, trade, symbol, stock, source, author) 
						VALUES ('" . $date1 . "', '" . $op . "', '" . $tp . "', 
						'" . $sl. "', '" . $trade . "', '" . $symbol. "', 'forex', 'etoro.com', '" . $traderfile  . "'
							)"; 
		}
		
		  mysql_query($data);	  
		}
	
}

$objects = json_decode($json2);

foreach($objects->Positions as $object) {

	foreach($object as $obj) {

	  
	     $op = $obj->OpenRate;
	     if(empty($op))continue; 
    
	    //$opentime=preg_replace("/[^0-9]/", '', $obj->OriginalOpenDate);
	    //preg_match('/[0-9]+/', $opentime, $matches);
	    
	    if($obj->IsBuy == 1)$trade="Buy";  else $trade = 'Sell';  
	    $symbol=str_replace("-", "", $obj->Market->Symbol->Name);
	    $symbol=strtoupper($symbol);	    
	    $sl =$obj->StopLoss;
	    $tp =$obj->TakeProfit;
	    $closetime=$obj->CloseDate;   
	    $cp=$obj->CloseRate;	        
	 
		  //echo  "<pre>";
		  //print_r($obj);
		  //echo "</pre>";
		    
		$sql = sprintf( "SELECT symbol, closedate FROM signals WHERE author = '%s' AND op = '%s' ", $traderfile, $op);
		$result = mysql_query( $sql ) or die( mysql_error() );
		$row = mysql_fetch_array($result);
		$symbol1= $row['symbol'];
		
		if(empty($row['closedate']))$date2=date('Y-m-d H:i:s', time());
		
		if($symbol1 != '' && $cp > 0)
		{
		
		   $data = "UPDATE signals SET tp='" . $tp . "' , st='" . $sl . "' , cp='". $cp ."', closedate='". $date2."'  WHERE op='" . $op . "' AND opendate='".$date1."' AND symbol='".$symbol1."' and author = '" . $traderfile  ."')"; 
		
		}
		else {
		  /**
		   $data = "INSERT INTO signals (opendate, closedate, cp, op, tp, st, trade, symbol, stock, source, author) 
						VALUES ('" . $date1 . "', '" . $date2 . "', '" . $cp . "','" . $op . "', '" . $tp . "', 
						'" . $sl. "', '" . $trade . "', '" . $symbol. "', 'forex', 'etoro.com', '" . $traderfile  . "'
							)"; 
		  **/
		}
		
		  mysql_query($data);

		}
	
}

?>