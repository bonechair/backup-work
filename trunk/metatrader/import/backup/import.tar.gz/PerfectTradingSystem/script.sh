#!/bin/bash

echo "Running Import";
cd /var/www/import/PerfectTradingSystem
php -f import.php
