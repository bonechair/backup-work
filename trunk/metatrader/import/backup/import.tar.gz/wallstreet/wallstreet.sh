#!/bin/bash

echo "Running Import";
cd /var/www/import/wallstreet
wget http://www.myfxbook.com/statements/95290/statement.csv
mv statement.csv wallstreet.csv
chmod 777 wallstreet.csv
php -f wallstreetimport.php 