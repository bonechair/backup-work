<?php
echo "Processing";
   date_default_timezone_set('Africa/Johannesburg'); 
$con = mysql_connect("localhost","bonechair","editer888");
if (!$con) {
    die('Could not connect: ' . mysql_error());
}

mysql_select_db('mysignals', $con) or die('Could not select database.');
$traderfile = 'lospaccone76';

$json = file_get_contents("https://openbook.etoro.com/API/Users/Positions/lospaccone76/real/current/?_=1391420788850");
$json2 = file_get_contents("https://openbook.etoro.com/API/Users/Positions/lospaccone76/real/history/?_=1391420788851");

include("../etoro.php");
?>