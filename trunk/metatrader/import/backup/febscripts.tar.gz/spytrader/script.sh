#!/bin/bash

echo "Running Import";
cd /var/www/import/spytrader
php -f import.php
