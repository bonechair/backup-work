<?php

echo "Processing";
$con = mysql_connect("localhost","bonechair","editer888");
if (!$con) {
    die('Could not connect: ' . mysql_error());
}

mysql_select_db('mysignals', $con) or die('Could not select database.');


$traderfile = 'PerfectTradingSystem';

$file1 = "http://www.fxstat.com/systems/ajaxlist/Perfect_System_Trading-18763?&format=opentrades&p=1&per=1000&_=1391075533793";
$file2 = "http://www.fxstat.com/systems/ajaxlist/Perfect_System_Trading-18763?&format=history&p=1&per=40&_=1391075533794";

include("../fxstat.php");

?>