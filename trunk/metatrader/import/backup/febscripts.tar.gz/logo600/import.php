<?php
echo "Processing";
   date_default_timezone_set('Africa/Johannesburg'); 
$con = mysql_connect("localhost","bonechair","editer888");
if (!$con) {
    die('Could not connect: ' . mysql_error());
}

mysql_select_db('mysignals', $con) or die('Could not select database.');
$traderfile = 'Logo600';

$json = file_get_contents("https://openbook.etoro.com/API/Users/Positions/logo600/real/current/?_=13909969097413");
$json2 = file_get_contents("https://openbook.etoro.com/API/Users/Positions/logo600/real/history/?_=1390996909743");

include("../etoro.php");
?>