#!/bin/bash

echo "Running Import";
cd /var/www/import/logo600
php -f import.php

echo "Running Import";
cd /var/www/import/lospaccone76
php -f import.php

echo "Running Import";
cd /var/www/import/malsolo
php -f import.php

echo "Running Import";
cd /var/www/import/lorenoem
php -f import.php

echo "Running Import";
cd /var/www/import/rowaihy
php -f import.php

echo "Running Import";
cd /var/www/import/ykforex
php -f import.php

