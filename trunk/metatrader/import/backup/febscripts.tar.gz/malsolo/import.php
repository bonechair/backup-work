<?php
echo "Processing";
   date_default_timezone_set('Africa/Johannesburg'); 
$con = mysql_connect("localhost","bonechair","editer888");
if (!$con) {
    die('Could not connect: ' . mysql_error());
}

mysql_select_db('mysignals', $con) or die('Could not select database.');
$traderfile = 'Malsolo';

$json = file_get_contents("https://openbook.etoro.com/API/Users/Positions/malsolo/real/current/?_=1391429018025");
$json2 = file_get_contents("https://openbook.etoro.com/API/Users/Positions/malsolo/real/history/?_=1391429018026");

include("../etoro.php");
?>