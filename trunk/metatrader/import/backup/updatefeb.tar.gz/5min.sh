#!/bin/bash

echo "Running Import";

/usr/bin/php -f /var/www/import/fxjunction.php

/usr/bin/php -f /var/www/import/etoro.php



