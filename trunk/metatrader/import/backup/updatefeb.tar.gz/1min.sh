#!/bin/bash

echo "Running csv generate";
cd /var/www/import/
rm signals.csv
mysql -ubonechair -pediter888 mysignals -e  "SELECT id, opendate, closedate, op, cp, tp, st, trade, symbol FROM signals WHERE (trade = 'Sell' || trade = 'Buy') GROUP by symbol, opendate, author ORDER by opendate DESC LIMIT 3000  INTO OUTFILE '/var/www/import/signals.csv' FIELDS TERMINATED BY ',' LINES TERMINATED BY '\n'"
cp signals.csv /var/www/import/metatrader/tester/files/signals.csv
cp signals.csv /var/www/import/metatrader/experts/files/signals.csv

