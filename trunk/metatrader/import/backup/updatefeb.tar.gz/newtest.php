<?php
require('simple_html_dom.php');

$postdata = http_build_query(
    array(
        'accountID' => '816032180',
        'stat' => 'closed'
    )
);

$opts = array('http' =>
    array(
        'method'  => 'POST',
        'header'  => 'Content-type: application/x-www-form-urlencoded',
        'content' => $postdata
    )
);

$context  = stream_context_create($opts);

$result = file_get_contents('https://www.fxjunction.com/signals/', false, $context);

$html = str_get_html($result );
    echo "<pre>";
    print_r($html );
    echo "</pre>";


?>